#!/usr/bin/env python3
"""
Fast Browser Use — Portable Binary Loader
Research-grade Cloudflare bypass stack (August 2026)
"""

import os, sys, subprocess, platform, shutil, json

SKILL_ROOT = os.path.dirname(os.path.abspath(__file__))
BIN_DIR = os.path.join(SKILL_ROOT, "bin")
CONFIG_PATH = os.path.join(SKILL_ROOT, "loader.json")

DEFAULT_CONFIG = {
    "binaries": {
        "nodriver": {
            "type": "pip",
            "package": "nodriver",
            "import_test": "nodriver",
            "post_install": None
        },
        "patchright": {
            "type": "pip",
            "package": "patchright",
            "import_test": "patchright",
            "post_install": "python -m patchright install chrome"
        },
        "camoufox": {
            "type": "pip",
            "package": "camoufox",
            "import_test": "camoufox",
            "post_install": "python -m camoufox fetch"
        },
        "curl_cffi": {
            "type": "pip",
            "package": "curl_cffi",
            "import_test": "curl_cffi",
            "post_install": None
        }
    },
    "system_deps": {
        "linux": ["chromium-browser", "chromium", "google-chrome-stable"],
        "darwin": ["/Applications/Google Chrome.app"],
        "windows": ["C:/Program Files/Google/Chrome/Application/chrome.exe"]
    }
}

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def run_cmd(cmd, cwd=None):
    print(f"[RUN] {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    return result.returncode == 0

def check_import(module_name):
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False

def install_pip(package, post_install=None):
    if run_cmd(f"{sys.executable} -m pip install {package}"):
        if post_install:
            run_cmd(post_install)
        return True
    return False

def detect_chrome():
    system = platform.system().lower()
    candidates = DEFAULT_CONFIG["system_deps"].get(system, [])
    path_chrome = shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
    if path_chrome:
        candidates.insert(0, path_chrome)
    for c in candidates:
        if os.path.exists(c):
            return c
    return None

def load_all():
    ensure_dir(BIN_DIR)
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        print(f"[CONFIG] Created {CONFIG_PATH}")

    with open(CONFIG_PATH) as f:
        config = json.load(f)

    results = {}
    for name, spec in config["binaries"].items():
        print(f"\n[LOAD] {name} ...")
        if check_import(spec["import_test"]):
            print(f"  OK Already installed")
            results[name] = "already_present"
            continue
        if spec["type"] == "pip":
            if install_pip(spec["package"], spec.get("post_install")):
                if check_import(spec["import_test"]):
                    print(f"  OK Installed and verified")
                    results[name] = "installed"
                else:
                    print(f"  FAIL Import failed after install")
                    results[name] = "import_failed"
            else:
                print(f"  FAIL Install failed")
                results[name] = "install_failed"

    chrome = detect_chrome()
    if chrome:
        print(f"\n[CHROME] Found: {chrome}")
        results["chrome_binary"] = chrome
    else:
        print(f"\n[CHROME] WARN Not found — install Chrome for Patchright channel=chrome")
        results["chrome_binary"] = None

    print(f"\n{'='*50}")
    print("LOADER SUMMARY")
    print(f"{'='*50}")
    for k, v in results.items():
        status = "OK" if v in ("already_present", "installed") or v else "FAIL"
        print(f"  [{status}] {k}: {v}")

    with open(os.path.join(SKILL_ROOT, "loader-state.json"), "w") as f:
        json.dump(results, f, indent=2)
    return results

def test_nodriver():
    import asyncio
    import nodriver as uc
    async def _test():
        browser = await uc.start()
        page = await browser.get("https://httpbin.org/ip")
        await page.sleep(2)
        content = await page.get_content()
        browser.stop()
        return content
    return asyncio.run(_test())

def test_curl_cffi():
    from curl_cffi import requests
    r = requests.get("https://httpbin.org/ip", impersonate="chrome")
    return r.json()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python loader.py <command>")
        print("Commands: load | test | chrome")
        sys.exit(0)
    cmd = sys.argv[1]
    if cmd == "load":
        load_all()
    elif cmd == "test":
        print("Testing nodriver...")
        try:
            print(test_nodriver()[:500])
        except Exception as e:
            print(f"nodriver test failed: {e}")
        print("\nTesting curl_cffi...")
        try:
            print(test_curl_cffi())
        except Exception as e:
            print(f"curl_cffi test failed: {e}")
    elif cmd == "chrome":
        print(f"Chrome: {detect_chrome()}")
    else:
        print(f"Unknown command: {cmd}")
