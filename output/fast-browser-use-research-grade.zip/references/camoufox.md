# Camoufox — Firefox Alternative

## Install
pip install camoufox
python -m camoufox fetch

## Basic usage
from camoufox.sync_api import Camoufox

with Camoufox(headless=True) as browser:
    page = browser.new_page()
    page.goto("https://abrahamjuliot.github.io/creepjs/")
    time.sleep(10)
    page.screenshot(path="creepjs.png")

## Why Firefox?
- Firefox TLS shape is whitelisted on many Chrome-blocking gates
- C-level patches for canvas, WebGL, screen geometry
- Native C motion trajectories for cursor physics

## Virtual display mode
with Camoufox(headless='virtual') as browser:
    ...
