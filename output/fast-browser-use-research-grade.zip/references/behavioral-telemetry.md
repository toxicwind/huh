# Behavioral Telemetry at Scale

## What gets detected at volume
- Same page order across sessions
- Identical scroll depths
- Fixed click timing (deterministic intervals)
- No idle time between actions
- Always starting from blank state

## Human-like patterns
import random
import numpy as np

# Log-normal delays (right-skewed like humans)
def delay(mu=0.5, sigma=0.3):
    return random.lognormvariate(mu, sigma)

# Variable scroll with pauses
async def human_scroll(page):
    for _ in range(random.randint(3, 8)):
        page.mouse.wheel(0, random.randint(200, 800))
        await asyncio.sleep(delay(0.8, 0.4))
        if random.random() < 0.2:
            await asyncio.sleep(delay(2.0, 0.5))

# Mouse trajectory with bezier curves
def bezier_move(start, end, steps=20):
    cp1 = (start[0] + random.randint(-100, 100), start[1] + random.randint(-50, 50))
    cp2 = (end[0] + random.randint(-100, 100), end[1] + random.randint(-50, 50))
    points = []
    for t in np.linspace(0, 1, steps):
        x = (1-t)**3*start[0] + 3*(1-t)**2*t*cp1[0] + 3*(1-t)*t**2*cp2[0] + t**3*end[0]
        y = (1-t)**3*start[1] + 3*(1-t)**2*t*cp1[1] + 3*(1-t)*t**2*cp2[1] + t**3*end[1]
        points.append((x, y))
    return points

## A/B testing framework
- Run new behavior on 20% of sessions
- Compare 403/429/captcha rates vs control
- Measure for 1-2 weeks before full rollout
