# JA4 Fingerprinting Defense (arXiv 2026)

## Key Paper: "Detecting Web Bad Bots via TLS Fingerprints"
- CatBoost classifier: 98.63% accuracy, AUC 0.998
- Most discriminative features: ja4_b, cipher_count, ext_count
- JA4 sorts extensions alphabetically (survives browser randomization)

## What JA4 sees
| Feature | Description |
|---------|-------------|
| t13 | TLS 1.3 |
| d1517 | Cipher suites (sorted) |
| h2 | HTTP/2 ALPN |
| 8daaf6152771 | Extension hash (sorted) |
| b1ff8ab2d16f | Signature algorithms |

## Common fingerprints
| Client | JA4 |
|--------|-----|
| Chrome | t13d1517h2_8daaf6152771_b1ff8ab2d16f |
| Firefox | t13d1715h2_5b57614c22b0_7121afd63204 |
| Python requests | t13i311000_e8f1e7e78f70_d41ae481755e |
| curl | t13i311000_bd868743f55c_fa269c3d986d |

## Defense
- Use real browser TLS stack (nodriver, Patchright+chrome)
- curl_cffi patches libcurl to match Chrome JA4
- Never use plain Python requests against Cloudflare
