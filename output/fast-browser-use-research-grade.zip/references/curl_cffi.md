# curl_cffi — HTTP-Only Floor

## Install
pip install curl_cffi

## Chrome impersonation (matches JA4 fingerprint)
from curl_cffi import requests
r = requests.get("https://example.com", impersonate="chrome")
print(r.status_code, len(r.text))

## With proxy
r = requests.get(
    "https://example.com",
    impersonate="chrome",
    proxies={"https": "http://user:pass@proxy:8080"}
)

## When to use
- Tier 1-2 sites (no JS execution needed)
- Health checks / proxy validation
- API endpoints behind Cloudflare
