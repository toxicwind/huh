# Shape Coherence — The Critical Rule

## The mistake everyone makes
Linux server + residential proxy + macOS User-Agent = instant block

## Why proxies alone fail
| Signal | Proxy fixes? | What actually matters |
|--------|-------------|----------------------|
| IP address | Yes | Residential/mobile ISP |
| TLS / JA4 fingerprint | No | Must match claimed browser |
| HTTP/2 SETTINGS | No | Client library fingerprint |
| navigator.platform | No | Must match OS in UA |
| Canvas/WebGL | No | Must match claimed GPU |
| screen resolution | No | Must match device type |

## Correct persona mapping
macOS Chrome persona:
  -> macOS TLS fingerprint (Chrome on macOS)
  -> North American residential IP
  -> America/Toronto timezone
  -> en-US, en-CA locales
  -> Retina display (devicePixelRatio=2)
  -> Safari/Chrome font stack

Windows Chrome persona:
  -> Windows TLS fingerprint
  -> European residential IP
  -> Europe/Berlin timezone
  -> de-DE locale
  -> 1920x1080, devicePixelRatio=1

## Session persistence
- Keep cookies, localStorage, cache across runs
- Rotate profiles only on identity change, not per request
- A/B test strategies for 1-2 weeks before switching
