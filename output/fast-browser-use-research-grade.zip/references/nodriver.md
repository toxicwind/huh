# nodriver — Primary Bypass

## Install
pip install nodriver

## Basic bypass (canadianinsider — blocks all others)
import asyncio
import nodriver as uc

async def main():
    browser = await uc.start()
    page = await browser.get('https://nowsecure.nl')
    await page.sleep(3)
    print(await page.get_content())
    browser.stop()

asyncio.run(main())

## With residential proxy
browser = await uc.start(browser_args=[
    '--proxy-server=http://user:pass@residential.proxy:8080',
    '--proxy-bypass-list=<-loopback>'
])

## Key advantage: No Playwright shim = no automation-protocol fingerprint
