# Research Sources (2026)

## Primary Papers
1. "Unmasking Web Agents with Multi-Layer Fingerprinting" (arXiv:2606.30119, June 2026)
   - 9 honeypot servers, 12 tools, 3 fingerprinting layers
   - BrowserUse-Stealth increases detectability
   - OpenClaw and Claude Chrome bypass all defenses

2. "Detecting Web Bad Bots via TLS Fingerprints" (arXiv:2602.09606, Feb 2026)
   - CatBoost: 98.63% accuracy, AUC 0.998
   - JA4 features: ja4_b, cipher_count, ext_count dominant

3. "Whose Agent Are You? Multi-Layer Fingerprinting and Attribution" (arXiv:2606.20910, June 2026)
   - Skyvern unique H2 fingerprint (priority weight 110)
   - HTTP header incoherence in AutoGen, Claude, Gemini

4. "Fingerprinting LLM Browser Agents via UI Traces" (arXiv:2605.14786, May 2026)
   - UI interaction patterns distinguish LLM agents
   - Qwen3.5, GPT-5.4, UI-TARS evaluated

5. "Toward Secure LLM Agents: Threat Surfaces, Attacks, Defenses" (arXiv:2606.10749, June 2026)
   - Comprehensive security review of LLM agent ecosystem

## Industry Benchmarks
- Ian Paterson Anti-Detect Browser Benchmark (Aug 2026)
  - 7 tools, 31 targets, 651 verdicts
  - nodriver: 28 OK, 0 blocked
  - curl_cffi ties CloakBrowser (26 OK)

- Browserless Anti-Detection Guide (Mar 2026)
  - Escalation path: REST -> /unblock -> BaaS -> BrowserQL
  - Stability beats cleverness

- ScrapingBee CreepJS Bypass (Jan 2026)
  - Camoufox achieves 0% headless score
