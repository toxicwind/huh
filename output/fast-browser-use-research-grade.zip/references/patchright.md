# Patchright — Playwright Drop-in

## Install
pip install patchright
patchright install chrome

## Launch with system Chrome (critical for fingerprint)
from patchright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(channel="chrome")
    page = browser.new_page()
    page.goto("https://example.com")

## Stealth context with consistency
context = browser.new_context(
    viewport={"width": 1920, "height": 1080},
    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    locale="en-US",
    timezone_id="America/New_York"
)
context.add_init_script(
    'Object.defineProperty(navigator, "webdriver", {get: () => undefined});'
)
