---
name: fast-browser-use
description: >
  Research-grade, Cloudflare-aware browser automation integrating 2026 arXiv
  findings on multi-layer fingerprinting, JA4 TLS detection, and LLM-agent
  attribution. Uses nodriver (CDP-native), Patchright, curl_cffi, and
  Camoufox with shape-coherent profile management.
allowed-tools: Read, Browser
---

# Fast Browser Use — Research-Grade Cloudflare Bypass (August 2026)

Built from 2026 arXiv papers, production benchmarks, and cross-layer detection research. Not baseline — this is the state-of-the-art evasion stack.

## Core Insight: Shape Coherence Beats Everything

Anti-bot systems in 2026 use multi-layer correlation, not single-signal validation. Your IP, TLS fingerprint, HTTP/2 frame ordering, browser properties, and behavior must all tell the same story. A residential proxy with a Linux TLS fingerprint and macOS navigator.platform is an instant flag.

## 2026 Detection Landscape (arXiv-Sourced)

### Layer 1: TLS / JA4 Fingerprinting

A February 2026 arXiv paper demonstrated that CatBoost classifiers using JA4 features achieve 98.63% accuracy isolating bots from legitimate traffic — from handshake data alone, before any HTTP request is processed.

Key JA4 signals:
- ja4_b (cipher suite structure) — most discriminative feature
- ext_count (extension richness)
- alpn_code (protocol negotiation)
- Post-quantum key exchange presence/absence (new 2026 vector)

What this means: Standard Python requests or Go net/http produce JA4 fingerprints that exist nowhere in the world except scrapers.

### Layer 2: HTTP/2 Frame Sequencing

HTTP/2 SETTINGS frame ordering and WINDOW_UPDATE signals fingerprint the client library. Skyvern has a uniquely identifiable stream-5 priority weight of 110.

### Layer 3: Browser Fingerprinting + Behavioral Telemetry

June 2026 arXiv research found that LLM web agents expose distinctive characteristics across all layers. Key findings:
- BrowserUse-Stealth mode increases detectability by using low-reputation datacenter IPs instead of residential proxies
- Stealth modes can increase detectability by introducing fingerprint inconsistencies
- Canvas/WebGL mismatches, font leaks, and WebRTC leaks are primary detection vectors

### Layer 4: Behavioral Correlation

At scale, identical execution paths (page order, delays, scroll depth, click timing) cluster into detectable signatures.

## Tool Stack (August 2026 Benchmark Rankings)

651 verdicts across 31 targets, 3 independent sweeps.

| Tool | OK | Blocked | Why It Wins / Fails |
|------|----|---------|---------------------|
| nodriver | 28 | 0 | Direct CDP, no Playwright shim, zero automation-protocol fingerprint |
| curl_cffi | 26 | 2 | TLS impersonation only; no JS engine |
| CloakBrowser | 26 | 2 | 49 C++ patches but same result as 21-line curl wrapper |
| Patchright | 25 | 3 | Best Playwright replacement; use channel=chrome |
| Camoufox | 25 | 3 | Firefox TLS shape; wins on google-search, loses on dev.to |
| Vanilla Playwright | 24 | 5 | Detectable CDP handshake sequence |

## Primary: nodriver (Zero Blocked Cells)

The only tool with zero blocked targets across 31 production sites. Drives system Chrome over raw WebSocket CDP — no Playwright accessibility layer, no Runtime.enable / Target.setAutoAttach startup sequence that anti-bot gates fingerprint.

```python
import asyncio
import nodriver as uc

async def bypass():
    browser = await uc.start()
    page = await browser.get('https://canadianinsider.com')
    await page.sleep(5)
    content = await page.get_content()
    await page.save_screenshot("proof.png")
    browser.stop()

asyncio.run(bypass())
```

Install: pip install nodriver

Tradeoff: AGPL-3.0 license. asyncio object model requires adapter layer in Playwright codebases.

## Fallback: Patchright + channel=chrome

Drop-in Playwright replacement. The channel=chrome flag runs system Chrome 148 — fingerprint protection at a layer no runtime patch can replicate.

```python
from patchright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(channel="chrome", headless=False)
    context = browser.new_context(
        viewport={"width": 1920, "height": 1080},
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    )
    page = context.new_page()
    page.goto("https://target-site.com")
```

Install: pip install patchright && patchright install chrome

## Firefox Alternative: Camoufox

Custom Firefox build with C-level spoofing. Firefox TLS shape is whitelisted on many Chrome-blocking gates. 0% headless score on CreepJS.

```python
from camoufox.sync_api import Camoufox

with Camoufox(headless=True) as browser:
    page = browser.new_page()
    page.goto("https://abrahamjuliot.github.io/creepjs/")
```

Install: pip install camoufox && python -m camoufox fetch

## HTTP-Only: curl_cffi

For tier 1-2 sites without JS. Patches libcurl to emit Chrome JA3/JA4 fingerprint. 26/31 targets with a 21-line wrapper.

```python
from curl_cffi import requests
r = requests.get("https://target-site.com", impersonate="chrome")
print(r.text)
```

Install: pip install curl_cffi

## Shape-Coherent Profile Management

The #1 mistake: Heavy randomization increases detection risk. Inconsistent profiles reset on every run, never building storage/cache/behavioral history.

Correct approach: Stateful personas with fixed traits across sessions.

```python
PERSONA = {
    "os": "macOS",
    "browser": "Chrome 148",
    "viewport": (1920, 1080),
    "device_pixel_ratio": 2.0,
    "timezone": "America/Toronto",
    "locale": "en-CA",
    "fonts": ["Helvetica Neue", "Arial", "Times"],
    "hardware_concurrency": 8,
    "device_memory": 8,
    "webrtc": "disabled",
}
```

Consistency rules:
- macOS persona -> macOS TLS fingerprint -> North American residential IP
- Windows persona -> Windows TLS fingerprint -> matching timezone
- Never mix: Linux server + residential proxy + macOS navigator.platform

## Behavioral Telemetry (Scale Detection)

At low volume, behavior doesn't matter. At scale, identical patterns cluster.

```python
import random

def human_delay(action_type="click"):
    base = {"click": 0.8, "scroll": 1.5, "type": 0.05}[action_type]
    return random.lognormvariate(mu=0, sigma=0.5) * base

def human_scroll():
    for _ in range(random.randint(3, 8)):
        page.mouse.wheel(0, random.randint(300, 700))
        asyncio.sleep(random.uniform(0.5, 2.0))
```

## Escalation Path (Browserless Model)

Don't start with the heaviest tool. Escalate only when needed.

| Stage | Tool | When |
|-------|------|------|
| 1 | curl_cffi | Static HTML, no JS |
| 2 | nodriver | JS-rendered, Cloudflare-gated |
| 3 | Patchright + stealth route | Existing Playwright codebase |
| 4 | Camoufox | Chrome-shaped gates, Firefox whitelisted |
| 5 | BrowserQL / BaaS | CAPTCHA + session continuity required |

## huh Project Integration

```
skill://fast-browser-use
├── research/
├── benchmarks/
├── profiles/
├── nodriver/
├── patchright/
├── camoufox/
├── curl_cffi/
└── telemetry/
```

Trigger: Load fast-browser-use with cloudflare bypass
