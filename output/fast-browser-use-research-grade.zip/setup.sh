#!/bin/bash
set -e
echo "[SETUP] Fast Browser Use Research-Grade Stack"
echo "[SETUP] Platform: $(uname -s)"
PYTHON="${PYTHON:-python3}"
$PYTHON --version
echo "[SETUP] Installing loader dependencies..."
$PYTHON -m pip install --upgrade pip setuptools wheel 2>/dev/null || true
echo "[SETUP] Loading binaries..."
$PYTHON loader.py load
echo "[SETUP] Done. Run: $PYTHON loader.py test"
