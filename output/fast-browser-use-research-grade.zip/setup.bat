@echo off
echo [SETUP] Fast Browser Use Research-Grade Stack
python --version
python -m pip install --upgrade pip setuptools wheel 2>nul
echo [SETUP] Loading binaries...
python loader.py load
echo [SETUP] Done. Run: python loader.py test
