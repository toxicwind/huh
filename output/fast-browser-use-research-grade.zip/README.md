# Fast Browser Use — Research-Grade Portable Stack

Cloudflare-aware browser automation integrating 2026 arXiv research.

## Quick Start

```bash
bash setup.sh        # Linux/macOS
setup.bat            # Windows
```

## Manual

```bash
python loader.py load    # Install all binaries
python loader.py test    # Run smoke tests
python loader.py chrome  # Detect Chrome binary
```

## Components

| Component | Type | Purpose |
|-----------|------|---------|
| nodriver | pip | Primary bypass (0 blocked cells) |
| Patchright | pip | Playwright drop-in + channel=chrome |
| Camoufox | pip | Firefox alternative (0% headless) |
| curl_cffi | pip | HTTP-only floor (JA4 impersonation) |
| loader.py | script | Portable binary manager |

## Research

- arXiv:2606.30119 — Multi-layer fingerprinting
- arXiv:2602.09606 — JA4 TLS detection (98.63%)
- arXiv:2606.20910 — LLM-agent attribution
- arXiv:2605.14786 — UI trace fingerprinting
- Ian Paterson Benchmark — 651 verdicts, 31 targets

## License

AGPL-3.0 (nodriver dependency)
